import './App.css';
import ToDo from './components/ToDo';

function App() {
  return <ToDo/>
}

export default App;
